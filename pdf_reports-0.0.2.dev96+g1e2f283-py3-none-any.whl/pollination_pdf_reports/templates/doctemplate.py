from pathlib import Path
from functools import partial
import pandas as pd
from typing import List
import json
import numpy as np
from io import BytesIO
import datetime
import logging

from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import simpleSplit
from reportlab.lib.units import mm, cm, inch
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, _baseFontNameB
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.graphics.shapes import Drawing, Circle, Rect, Polygon, Line, PolyLine, Group, String
from reportlab.platypus import SimpleDocTemplate, BaseDocTemplate, Flowable, Paragraph, \
    Table, TableStyle, PageTemplate, Frame, PageBreak, NextPageTemplate, \
    Image, FrameBreak, Spacer, HRFlowable, CondPageBreak, KeepTogether, TopPadder, \
    UseUpSpace, AnchorFlowable, KeepInFrame, PageBreakIfNotEmpty
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.graphics import shapes
from reportlab.platypus.tables import _ExpandedCellTuple

from .pagetemplate import Container


logger = logging.getLogger('reportlab.platypus')

class Document():
    def __init__(self, page_size = None, left_margin = None, right_margin = None,
                 bottom_margin = None, top_margin = None, templates = None):
        self.page_size = page_size
        self.left_margin = left_margin
        self.right_margin = right_margin
        self.bottom_margin = bottom_margin
        self.top_margin = top_margin
        if templates is None:
            templates = []
        self.templates = templates
        self.pages = []

    @property
    def page_size(self):
        return self._page_size

    @page_size.setter
    def page_size(self, page_size):
        self._page_size = page_size

    @property
    def left_margin(self):
        return self._left_margin

    @left_margin.setter
    def left_margin(self, left_margin):
        self._left_margin = left_margin

    @property
    def right_margin(self):
        return self._right_margin

    @right_margin.setter
    def right_margin(self, right_margin):
        self._right_margin = right_margin

    @property
    def bottom_margin(self):
        return self._bottom_margin

    @bottom_margin.setter
    def bottom_margin(self, bottom_margin):
        self._bottom_margin = bottom_margin

    @property
    def top_margin(self):
        return self._top_margin

    @top_margin.setter
    def top_margin(self, top_margin):
        self._top_margin = top_margin

    @property
    def templates(self):
        return self._templates

    @templates.setter
    def templates(self, templates):
        # TODO: add check for identical template identifiers
        self._templates = templates

    @property
    def pages(self):
        return self._pages

    @pages.setter
    def pages(self, pages):
        self._pages = pages

    def add_template(self, template):
        # TODO: add check for identical template identifiers
        self._templates.append(template)

    def add_pages(self, pages):
        if isinstance(pages, (list, tuple)):
            self._pages.extend(pages)
        else:
            self._pages.append(pages)

    def generate_pdf(
            self, filename: str, showBoundary: bool = False, skip_pages: int = 1,
            start_on_skip_pages: bool = True, skip_templates: list = None,
            title: str = None
        ):
        if not filename.endswith('.pdf'):
            filename = filename + '.pdf'
        pdf = MyDocTemplate(
            filename, pagesize=self.page_size, leftMargin=self.left_margin,
            rightMargin=self.right_margin, bottomMargin=self.bottom_margin,
            topMargin=self.top_margin, showBoundary=showBoundary,
            skip_pages=skip_pages, start_on_skip_pages=start_on_skip_pages,
            skip_templates=skip_templates, title=title
        )

        story = []
        for index, page in enumerate(self.pages):
            frames = []
            for container in page.containers:
                frame = container.to_frame(showBoundary=showBoundary)
                frames.append(frame)
                story.extend(container.content)
                story.append(FrameBreak())
            # for header in page.headers:
            #     frame = header.to_frame(showBoundary=showBoundary)
            #     frames.append(frame)
            #     story.extend(header.content)
            #     story.append(FrameBreak())
            # for footer in page.footers:
            #     frame = footer.to_frame(showBoundary=showBoundary)
            #     frames.append(frame)
            #     story.extend(footer.content)
            #     story.append(FrameBreak())
            page_template = PageTemplate(
                page.identifier, frames=frames, pagesize=self.page_size,
                onPage=partial(_header_and_footer, headers=page.headers, footers=page.footers, showBoundary=showBoundary)
            )
            pdf.addPageTemplates(page_template)

            if index < len(self.pages) - 1:
                nextTemplate = self.pages[index + 1].identifier
                story.append(PageBreakIfNotEmpty(nextTemplate=nextTemplate))

        pdf.multiBuild(story)


def _header_and_footer(canvas, doc, headers, footers, showBoundary):
    _header(canvas, doc, headers, showBoundary)
    _footer(canvas, doc, footers, showBoundary)


def _header(canvas, doc, headers: List[Container], showBoundary):
    canvas.saveState()
    for header in reversed(headers):
        if header.content:
            accumulated_h = 0
            for content in header.content:
                w, h = content.wrap(header.width, header.height)
                if isinstance(content, Paragraph):
                    content_width = stringWidth(
                        content.text, fontName=content.style.fontName,
                        fontSize=content.style.fontSize
                    )
                if showBoundary:
                    canvas.rect(header.x, header.y, header.width, header.height, stroke=1, fill=0)

                if header.horizontal_align == 'LEFT':
                    content.drawOn(
                        canvas, header.x, header.y + accumulated_h
                    )
                elif header.horizontal_align == 'CENTER':
                    content.drawOn(
                        canvas, header.x + (header.width - content_width) / 2,
                        header.y + accumulated_h
                    )
                elif header.horizontal_align == 'RIGHT':
                    content.drawOn(
                        canvas, header.x + header.width - content_width,
                        header.y + accumulated_h
                    )
                accumulated_h += h + h*0.1
    if headers:
        canvas.line(
        doc.leftMargin,
        headers[0].y,
        doc.leftMargin + doc.width,
        headers[0].y)

    canvas.restoreState()

def _footer(canvas, doc, footers: List[Container], showBoundary):
    canvas.saveState()
    for footer in footers:
        if footer.content:
            accumulated_h = 0
            for content in footer.content:
                w, h = content.wrap(footer.width, footer.height)
                accumulated_h += h + h*0.1
                if isinstance(content, Paragraph):
                    content_width = stringWidth(
                        content.text, fontName=content.style.fontName,
                        fontSize=content.style.fontSize
                    )
                if showBoundary:
                    canvas.rect(footer.x, footer.y, footer.width, footer.height, stroke=1, fill=0)

                if footer.horizontal_align == 'LEFT':
                    content.drawOn(
                        canvas, footer.x, footer.y + footer.height - accumulated_h
                    )
                elif footer.horizontal_align == 'CENTER':
                    content.drawOn(
                        canvas, footer.x + (footer.width - content_width) / 2,
                        footer.y + footer.height - accumulated_h
                    )
                elif footer.horizontal_align == 'RIGHT':
                    content.drawOn(
                        canvas, footer.x + footer.width - content_width,
                        footer.y + footer.height - accumulated_h
                    )

    canvas.restoreState()


class TotalPages():
    """
    A class which holds the total number of pages of a PDF

    Starting value for number_of_pages is 0
    (but could be any other integer as well)
    """

    def __init__(self):
        self.number_of_pages = 0


class MyDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kw):
        self.skip_pages = kw.pop('skip_pages', 0)
        self.start_on_skip_pages = kw.pop('start_on_skip_pages', None)
        self.skip_templates = kw.pop('skip_templates', None)
        BaseDocTemplate.__init__(self, filename, **kw)
        self.total_pages = 0

    @property
    def skip_templates(self):
        """Return skip_templates."""
        return self._skip_templates

    @skip_templates.setter
    def skip_templates(self, value):
        if value is None:
            value = []
        self._skip_templates = value

    def handle_pageBegin(self):
        """Perform actions required at beginning of page. Should not normally
        be called directly."""
        if not self.pageTemplate.id in self.skip_templates:
            self.page += 1
        if self._debug: logger.debug("beginning page %d" % self.page)
        self.pageTemplate.beforeDrawPage(self.canv,self)
        self.pageTemplate.checkPageSize(self.canv,self)
        self.pageTemplate.onPage(self.canv,self)
        for f in self.pageTemplate.frames: f._reset()
        self.beforePage()
        #keep a count of flowables added to this page.  zero indicates bad stuff
        self._curPageFlowableCount = 0
        if hasattr(self,'_nextFrameIndex'):
            del self._nextFrameIndex
        self.frame = self.pageTemplate.frames[0]
        self.frame._debug = self._debug
        self.handle_frameBegin(pageTopFlowables=self._pageTopFlowables)

        if self.total_pages < self.page:
            self.total_pages = self.page

        # print page numbers on page
        if not self.pageTemplate.id in self.skip_templates:
            page = self.page
            self.canv.setFont('Helvetica', 9)
            page_x_of_y = f'Page {str(page)} of {str(self.total_pages)}'
            self.canv.drawRightString(x=190*mm, y=15*mm, text=page_x_of_y)


    def afterFlowable(self, flowable):
        """Define actions that shall be performed after a flowable is added.

        Function is called by the 'multiBuild' method of the 'BaseDocTemplate'
        class."""
        def check_paragraph_heading(flowable: Paragraph):
            txt_of_heading = flowable.getPlainText()
            page = self.page
            if self.start_on_skip_pages:
                page -= self.skip_pages

            if flowable.style.name == 'Heading1':
                key = 'h1-%s' % self.seq.nextf('heading1')
                self.canv.bookmarkPage(key)
                self.notify(kind='TOCEntry',
                            stuff=(0, txt_of_heading, page, key))
                self.canv.addOutlineEntry(txt_of_heading, key, 0, 0)

            if flowable.style.name == 'Heading2' or flowable.style.name == 'Heading2_Appendix':
                key = 'h2-%s' % self.seq.nextf('heading2')
                self.canv.bookmarkPage(key)
                self.notify(kind='TOCEntry',
                            stuff=(1, txt_of_heading, page, key))
                self.canv.addOutlineEntry(txt_of_heading, key, 1, 0)
                if flowable.style.name == 'Heading2_Appendix':
                    self.notify(kind='TOCAppendix',
                                stuff=(0, txt_of_heading, page, key))

            if flowable.style.name == 'Heading3_Appendix':
                key = 'h3-%s-appendix' % self.seq.nextf('heading3')
                self.canv.bookmarkPage(key)
                self.notify(kind='TOCAppendix',
                            stuff=(1, txt_of_heading, page, key))

            if flowable.style.name == 'TableOfContents':
                key = 'h1-%s' % self.seq.nextf('heading1')
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(txt_of_heading, key, 0, 0)

        def unpack_cell_values(table: Table):
            for row in table._cellvalues:
                for cell in row:
                    if isinstance(cell, _ExpandedCellTuple):
                        for item in cell:
                            if isinstance(item, Paragraph):
                                check_paragraph_heading(item)
                    if isinstance(cell, Paragraph):
                        check_paragraph_heading(cell)

        if isinstance(flowable, Paragraph):
            check_paragraph_heading(flowable)

        if isinstance(flowable, Table):
            unpack_cell_values(flowable)



    # def afterFlowable(self, flowable):
    #     "Registers TOC entries."
    #     if isinstance(flowable, Paragraph):
    #         text = flowable.getPlainText()
    #         style = flowable.style.name
    #         if style == 'Heading1':
    #             key = 'h1-%s' % self.seq.nextf('Heading1')
    #             self.canv.bookmarkPage(key)
    #             self.notify('TOCEntry', (0, text, self.page))
    #         if style == 'Heading2':
    #             key = 'h2-%s' % self.seq.nextf('heading2')
    #             self.canv.bookmarkPage(key)
    #             self.notify('TOCEntry', (1, text, self.page))

    # def handle_pageBreak(self, slow=None):
    #     '''ignore page break on empty page'''
    #     if self._curPageFlowableCount == 0:
    #         return

    #     if self._pageBreakQuick and not slow:
    #         self.handle_pageEnd()
    #     else:
    #         n = len(self._hanging)
    #         while len(self._hanging)==n:
    #             self.handle_frameEnd()
