"""Module for page templates."""
from typing import Tuple, List

from reportlab.platypus import Paragraph, Frame
from reportlab.lib.styles import ParagraphStyle

from pollination_pdf_reports.pdf.styles import STYLES


class Container(object):
    """Container object.

    When adding content to the Container, one should use the add_content method
    rather than setting the content property directly. Using the add_content
    method will append content to the content property.

    Args:
        identifier: Identifier of Container.
        x: The lower left x-coordinate of the Container.
        y: The lower left y-coordinate of the Container.
        width: The width of the Container.
        height: The height of the Container.

    Properties:
        * identifier
        * x
        * y
        * width
        * height
        * content
        * horizontal_align
    """
    __slots__ = ('_identifier', '_x', '_y', '_width', '_height', '_content', '_horizontal_align')

    def __init__(self, identifier: str, x: float, y: float, width: float,
                 height: float, content: list = None, horizontal_align: str = 'LEFT'):
        """Initialize a Container."""
        self.identifier = identifier
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        if content is None:
            content = []
        self.content = content
        self.horizontal_align = horizontal_align

    @classmethod
    def from_dict(cls, container_dict):
        """Create a Container from a dictionary."""
        identifier = container_dict['identifier']
        x = container_dict['x']
        y = container_dict['y']
        width = container_dict['width']
        height = container_dict['height']
        content = container_dict['content']
        return cls(identifier, x, y, width, height, content)

    @property
    def identifier(self):
        """Return identifier."""
        return self._identifier

    @identifier.setter
    def identifier(self, identifier):
        assert isinstance(identifier, str)
        self._identifier = identifier

    @property
    def x(self):
        """Return x."""
        return self._x

    @x.setter
    def x(self, x):
        self._x = x

    @property
    def y(self):
        """Return y."""
        return self._y

    @y.setter
    def y(self, y):
        self._y = y

    @property
    def width(self):
        """Return width."""
        return self._width

    @width.setter
    def width(self, width):
        self._width = width

    @property
    def height(self):
        """Return height."""
        return self._height

    @height.setter
    def height(self, height):
        self._height = height

    @property
    def content(self):
        """Return content."""
        return self._content

    @content.setter
    def content(self, content):
        if not isinstance(content, (tuple, list)):
            content = [content]
        self._content = content

    @property
    def horizontal_align(self):
        """Return horizontal_align."""
        return self._horizontal_align

    @horizontal_align.setter
    def horizontal_align(self, horizontal_align):
        self._horizontal_align = horizontal_align

    def add_content(self, content):
        """Add content to the Container.
        
        Args:
            content: Content to add to the Container.
        """
        if isinstance(content, list):
            self.content.extend(content)
        else:
            self.content.append(content)

    def clear_content(self):
        """Clear the Container content."""
        self._content = []

    def to_frame(self, showBoundary: bool = False):
        """Convert Container to a ReportLab Frame."""
        frame = Frame(self.x, self.y, self.width, self.height, leftPadding=0,
                      bottomPadding=0, rightPadding=0, topPadding=0,
                      id=self.identifier, showBoundary=showBoundary)
        return frame


class ContainerText(Container):
    """ContainerText object.

    When adding content to the ContainerText, one should use the add_content
    method rather than setting the content property directly. Using the
    add_content method will append content to the content property.

    This container should be used only when text is the only content in the
    container.

    Args:
        identifier: Identifier of ContainerText.
        x: The lower left x-coordinate of the ContainerText.
        y: The lower left y-coordinate of the ContainerText.
        width: The width of the ContainerText.
        height: The height of the ContainerText.
        style: A ParagraphStyle object to style the text in the content property.

    Properties:
        * identifier
        * x
        * y
        * width
        * height
        * content
        * style
    """
    __slots__ = ('_style',)

    def __init__(self, identifier: str, x: float, y: float, width: float,
                 height: float, style: ParagraphStyle = None):
        """Initialize ContainerText."""
        Container.__init__(self, identifier, x, y, width, height)
        self.style = style

    @property
    def style(self):
        """Return style."""
        return self._style

    @style.setter
    def style(self, style):
        if style is not None and not isinstance(style, ParagraphStyle):
            raise TypeError('Style must be an instance of ParagraphStyle or None.')
        self._style = style

    def add_content(self, content: str):
        """Add content to the ContainerText.
        
        Args:
            content: Content to add to the ContainerText.
        """
        assert isinstance(content, str)
        content = Paragraph(content, self.style)
        self.content.append(content)


class Page(object):
    """A page object.

    Args:
        page_size: A tuple of the page size (width, height).
    
    Properties:
        * page_size
        * page_width
        * page_height
    """
    __slots__ = ('_page_size', '_page_width', '_page_height')

    def __init__(self, page_size: Tuple[float, float]):
        """Initialize a Page."""
        self.page_size = page_size

    @property
    def page_size(self):
        """Return pagesize."""
        return self._page_size

    @page_size.setter
    def page_size(self, page_size):
        assert isinstance(page_size, tuple)
        self._page_size = page_size
        self._page_width, self._page_height = page_size

    @property
    def page_width(self):
        """Return page width."""
        return self._page_width

    @property
    def page_height(self):
        """Return page page_height."""
        return self._page_height


class BaseLayout(Page):
    """A base layout.
    
    Args:
        identifier: The identifier of the layout.
        page_size: A tuple of the page size (width, height).
        left_margin: A float value of the left margin.
        right_margin: A float value of the right margin.
        bottom_margin: A float value of the bottom margin.
        top_margin: A float value of the top margin.
        containers: A list of Container objects.
        headers: A list of Container objects reserved for the header.
        footers: A list of Container objects reserved for the footer.

    Properties:
        * identifier
        * page_size
        * page_width
        * page_height
        * width
        * height
        * left_margin
        * right_margin
        * bottom_margin
        * top_margin
        * containers
        * headers
        * footers
        * unique_container_identifiers
    """
    def __init__(self, identifier: str, page_size: Tuple[float, float],
                 left_margin: float = 30, right_margin: float = 30,
                 bottom_margin: float = 30, top_margin: float = 30,
                 containers: List[Container] = None,
                 headers: List[Container] = None,
                 footers: List[Container] = None):
        """Initialize a BaseLayout."""
        Page.__init__(self, page_size)
        self.identifier = identifier
        self.left_margin = left_margin
        self.right_margin = right_margin
        self.bottom_margin = bottom_margin
        self.top_margin = top_margin
        self.width = self.page_width - self.left_margin - self.right_margin
        self.height = self.page_height - self.bottom_margin - self.top_margin
        if containers is None:
            containers = []
        self.containers = containers
        if headers is None:
            headers = []
        self.headers = headers
        if footers is None:
            footers = []
        self.footers = footers
        self._unique_container_identifiers = set()

    @property
    def identifier(self):
        """Return identifier."""
        return self._identifier

    @identifier.setter
    def identifier(self, identifier):
        assert isinstance(identifier, str)
        self._identifier = identifier

    @property
    def width(self):
        """Return width."""
        return self._width

    @width.setter
    def width(self, width):
        self._width = width

    @property
    def height(self):
        """Return height."""
        return self._height

    @height.setter
    def height(self, height):
        self._height = height

    @property
    def left_margin(self):
        """Return left margin."""
        return self._left_margin

    @left_margin.setter
    def left_margin(self, left_margin):
        self._left_margin = left_margin

    @property
    def right_margin(self):
        """Return right margin."""
        return self._right_margin

    @right_margin.setter
    def right_margin(self, right_margin):
        self._right_margin = right_margin

    @property
    def bottom_margin(self):
        """Return bottom margin."""
        return self._bottom_margin

    @bottom_margin.setter
    def bottom_margin(self, bottom_margin):
        self._bottom_margin = bottom_margin

    @property
    def top_margin(self):
        """Return top margin."""
        return self._top_margin

    @top_margin.setter
    def top_margin(self, top_margin):
        self._top_margin = top_margin

    @property
    def containers(self):
        """Return Containers."""
        return self._containers

    @containers.setter
    def containers(self, containers):
        self._containers = containers

    @property
    def headers(self):
        """Return header Containers."""
        return self._headers

    @headers.setter
    def headers(self, headers):
        self._headers = headers

    @property
    def footers(self):
        """Return footer Containers."""
        return self._footers

    @footers.setter
    def footers(self, footers):
        self._footers = footers

    @property
    def unique_container_identifiers(self):
        """Return unique Container identifiers.
        
        This return a set of the identifiers of all Containers in the object
        including containers, headers, and footers.
        """
        return self._unique_container_identifiers

    def add_containers(self, containers):
        """Add a list of Containers to the containers property.
        
        Args:
            containers: A list of Container objects.
        """
        if not isinstance(containers, (list, tuple)):
            containers = [containers]
        for container in containers:
            if container.identifier in self.unique_container_identifiers:
                raise ValueError(f'An object of type {type(container)} with '
                                 f'identifier {container.identifier} already '
                                 'exist.')
            self.unique_container_identifiers.add(container.identifier)
            self.containers.append(container)

    def clear_containers(self):
        """Clear the containers property."""
        for container in self.containers:
            self.unique_container_identifiers.remove(container.identifier)
        self._containers = []

    def add_headers(self, headers):
        """Add a list of Containers to the headers property.
        
        Args:
            headers: A list of Container objects.
        """
        if not isinstance(headers, (list, tuple)):
            headers = [headers]
        for header in headers:
            if header.identifier in self.unique_container_identifiers:
                raise ValueError(f'An object of type {type(header)} with '
                                 f'identifier {header.identifier} already '
                                 'exist.')
            self.unique_container_identifiers.add(header.identifier)
            self.headers.append(header)

    def clear_headers(self):
        """Clear the headers property."""
        for header in self.headers:
            self.unique_container_identifiers.remove(header.identifier)
        self._headers = []

    def add_footers(self, footers):
        """Add a list of Containers to the footers property.
        
        Args:
            footers: A list of Container objects.
        """
        if not isinstance(footers, (list, tuple)):
            footers = [footers]
        for footer in footers:
            if footer.identifier in self.unique_container_identifiers:
                raise ValueError(f'An object of type {type(footer)} with '
                                 f'identifier {footer.identifier} already '
                                 'exist.')
            self.unique_container_identifiers.add(footer.identifier)
            self.footers.append(footer)

    def clear_footers(self):
        """Clear the footers property."""
        for footer in self.footers:
            self.unique_container_identifiers.remove(footer.identifier)
        self._footers = []

    def add_container_content(self, identifier: str, content):
        """Add content to a Container by Container identifier.
        
        Args:
            identifier: Identifier of the Container.
            content: Content to add to the Container.
        """
        if not identifier in self.unique_container_identifiers:
            raise ValueError(f'Container with identifier {identifier} '
                             'was not found.')
        container = self.get_container_by_id(identifier)
        container.add_content(content)


    def get_container_by_id(self, identifier: str):
        """Get a Container by Container identifier.
        
        Args:
            identifier: Identifier of the Container.
        """
        if not identifier in self.unique_container_identifiers:
            raise ValueError(f'Container with identifier {identifier} '
                             'was not found.')
        for container in self.containers + self.headers + self.footers:
            if identifier == container.identifier:
                return container

    def create_grid_containers(
            self, columns: list = None, grid_width: float = None,
            grid_height: float = None, horizontal_padding: float = 0,
            vertical_padding: float = 0, row_ratio: list = None,
            column_ratio: list = None, horizontal_align: str = 'LEFT',
            vertical_align: str = 'TOP', identifier: str = 'frame'
            ):
        """Create a grid of Containers.
        
        Args:
            columns: A list of integers of the number of columns in each row.
                If None the default is [2, 2].
            grid_width: Width of the grid. If None the width is set to the page
                width (excluding left and right margin).
            grid_height: Height of the grid. If None the height is set to the
                page height (excluding top and bottom margin).
            horizontal_padding: Horizontal padding between Containers.
            vertical_padding: Vertical padding between Containers.
            row_ratio: A list of length equal to the number of rows. The values
                in the list must be the ratio between the row sizes, e.g., a
                list of [0.5, 0.5] will create two equal sized rows. If None
                the rows will be equally sized.
            column_ratio: A list of length equal to the number of rows. The
                values in the list must be a list of ratio between the column sizes,
                e.g., a list of [0.5, 0.5] will create two equal sized columns.
                A None value will create equal sized columns in the row.
            horizontal_align: Align the grid of Containers to the LEFT, RIGHT
                or CENTER.
            vertical_align: Align the grid of Containers to the TOP, BOTTOM
                or CENTER.
            identifier: An identifier to use as the base identifier. The
                identifiers of the Containers will be numbered based on this
                identifier, e.g., frame-1, frame-2, etc.

        Returns:
            A list of Containers.
        """
        if columns is None:
            columns = [2, 2]

        if grid_width is None:
            grid_width = self.width
        if grid_height is None:
            grid_height = self.height

        if row_ratio is None:
            row_ratio = [1 / len(columns)] * len(columns)
        if column_ratio is None:
            column_ratio = [None] * len(columns)

        assert len(columns) == len(column_ratio), ('Length of "column_ratio" '
            'must be equal to the length of "columns".')
        assert len(columns) == len(row_ratio), ('Length of "row_ratio" must be '
            'equal to the length of "columns".')
        for idx, _cr in enumerate(column_ratio):
            if isinstance(_cr, list):
                assert len(_cr) == columns[idx], ('Number of column ratios '
                    f'({len(_cr)}) do not match the number of columns '
                    f'({columns[idx]}).')
            elif _cr is None:
                column_ratio[idx] = [1 / columns[idx]] * columns[idx]

        available_height = grid_height - (len(columns) - 1) * vertical_padding

        row_heights = [int(available_height * ratio) for ratio in row_ratio]
        total_row_height = sum(row_heights) + (len(columns) - 1) * vertical_padding

        containers = []
        container_count = 1
        for row, num_cols in enumerate(columns):
            available_width = grid_width - (num_cols - 1) * horizontal_padding
            column_widths = [available_width * ratio for ratio in column_ratio[row]]
            total_column_width = sum(column_widths) + (num_cols - 1) * horizontal_padding
            for col in range(num_cols):
                width = column_widths[col]
                height = row_heights[row]
                if horizontal_align == 'LEFT':
                    x = sum(column_widths[:col]) + col * horizontal_padding + \
                        self.left_margin
                elif horizontal_align == 'RIGHT':
                    x = sum(column_widths[:col]) + col * horizontal_padding + \
                        self.left_margin + grid_width - total_column_width
                elif horizontal_align == 'CENTER':
                    x = sum(column_widths[:col]) + col * horizontal_padding + \
                        self.left_margin + grid_width*0.5 - total_column_width*0.5
                if vertical_align == 'TOP':
                    y = grid_height - sum(row_heights[:row+1]) - \
                        row * vertical_padding + self.bottom_margin
                elif vertical_align == 'BOTTOM':
                    y = grid_height - sum(row_heights[:row+1]) - \
                        row * vertical_padding + self.bottom_margin - \
                        grid_height + total_row_height
                elif vertical_align == 'CENTER':
                    y = grid_height - sum(row_heights[:row+1]) - \
                        row * vertical_padding + self.bottom_margin - \
                        grid_height*0.5 + total_row_height*0.5
                containers.append(
                    Container(f'{identifier}-{container_count}', x, y, width, height))
                container_count += 1

        return containers

    def create_headers(
            self, num_headers: int = 3, identifier: str = 'header',
            bottom_padding: float = None, top_padding: float = None):
        """Create Containers for header.
        
        Args:
            num_headers: The number of Containers. They are divided horizontally.
            identifier: An identifier to use as the base identifier. The
                identifiers of the Containers will be numbered based on this
                identifier, e.g., header-1, header-2, etc.
            bottom_padding: Bottom padding between the headers and the top margin.
                If None the default is 10% of the top margin value.
            top_padding: Top padding between the header and the top of the page.
                If None the default is 10% of the top margin value.
        
        Returns:
            A list of Containers.
        """
        if bottom_padding is None:
            bottom_padding = self.top_margin * 0.1
        if top_padding is None:
            top_padding = self.top_margin * 0.1

        containers = []
        for i in range(num_headers):
            if i == 0:
                horizontal_align = 'LEFT'
            elif i == num_headers - 1:
                horizontal_align = 'RIGHT'
            else:
                horizontal_align = 'CENTER'
            containers.append(
                Container(f'{identifier}-{i+1}',
                          x=self.left_margin+self.width*(i/num_headers),
                          y=self.bottom_margin+self.height+bottom_padding,
                          width=self.width/num_headers,
                          height=self.top_margin-bottom_padding-top_padding,
                          horizontal_align=horizontal_align)
            )

        return containers

    def create_footers(
            self, num_footers: int = 3, identifier: str = 'footer',
            bottom_padding: float = None, top_padding: float = None):
        """Create Containers for footer.
        
        Args:
            num_footers: The number of Containers. They are divided horizontally.
            identifier: An identifier to use as the base identifier. The
                identifiers of the Containers will be numbered based on this
                identifier, e.g., header-1, header-2, etc.
            bottom_padding: Bottom padding between the footers and the bottom of
                the page. If None the default is 10% of the bottom margin value.
            top_padding: Top padding between the footer and the top of bottom
                margin. If None the default is 10% of the bottom margin value.
        
        Returns:
            A list of Containers.
        """
        if bottom_padding is None:
            bottom_padding = self.top_margin * 0.1
        if top_padding is None:
            top_padding = self.top_margin * 0.1

        containers = []
        for i in range(num_footers):
            if i == 0:
                horizontal_align = 'LEFT'
            elif i == num_footers - 1:
                horizontal_align = 'RIGHT'
            else:
                horizontal_align = 'CENTER'
            containers.append(
                Container(f'{identifier}-{i+1}',
                          x=self.left_margin+self.width*(i/num_footers),
                          y=bottom_padding,
                          width=self.width/num_footers,
                          height=self.bottom_margin-bottom_padding-top_padding,
                          horizontal_align=horizontal_align)
            )

        return containers


class FrontPage(BaseLayout):
    """A front page template with multiple containers."""
    def __init__(self, identifier: str, page_size: Tuple[float, float],
                 left_margin: float, right_margin: float, bottom_margin: float,
                 top_margin: float):
        BaseLayout.__init__(self, identifier, page_size, left_margin,
                            right_margin, bottom_margin, top_margin)
        container_1 = ContainerText(
            'title', x=self.left_margin, y=self.bottom_margin + self.height * 0.7,
            width=self.width, height=self.height*0.04)
        container_1.style = STYLES['h1_c'].clone(
            name='h1_c_', fontSize=container_1.height, spaceBefore=0,
            spaceAfter=0, leading=0)
        container_2 = ContainerText(
            'project', x=self.left_margin, y=self.bottom_margin + self.height * 0.66,
            width=self.width, height=self.height*0.03)
        container_2.style = STYLES['h2_c'].clone(
            name='h2_c_', fontSize=container_2.height, spaceBefore=0,
            spaceAfter=0, leading=0)
        container_3 = ContainerText(
            'author', x=self.left_margin, y=self.bottom_margin + self.height * 0.60,
            width=self.width, height=self.height*0.02)
        container_3.style = STYLES['Normal_CENTER'].clone(
            name='Normal_CENTER_', fontSize=container_3.height, spaceBefore=0,
            spaceAfter=0, leading=0)
        container_4 = ContainerText(
            'date', x=self.left_margin, y=self.bottom_margin + self.height * 0.57,
            width=self.width, height=self.height*0.02)
        container_4.style = STYLES['Normal_CENTER'].clone(
            name='Normal_CENTER_', fontSize=container_4.height, spaceBefore=0,
            spaceAfter=0, leading=0)
        container_5 = Container(
            'frame-1', x=self.left_margin, y=self.bottom_margin,
            width=self.width, height=self.height*0.53)
        self.add_containers(
            [container_1, container_2, container_3, container_4, container_5])


class Template1(BaseLayout):
    """A basic template with one Container."""
    def __init__(self, identifier: str, page_size: Tuple[float, float],
                 left_margin: float, right_margin: float, bottom_margin: float,
                 top_margin: float):
        BaseLayout.__init__(self, identifier, page_size, left_margin,
                            right_margin, bottom_margin, top_margin)
        container = Container('frame-1',
                              x=self.left_margin,
                              y=self.bottom_margin,
                              width=self.width,
                              height=self.height)
        self.add_containers(container)
        headers = self.create_headers()
        self.add_headers(headers)
        footers = self.create_footers()
        self.add_footers(footers)


class Template2(BaseLayout):
    def __init__(self, identifier: str, page_size: Tuple[float, float],
                 left_margin: float, right_margin: float, bottom_margin: float,
                 top_margin: float):
        BaseLayout.__init__(self, identifier, page_size, left_margin,
                            right_margin, bottom_margin, top_margin)
        container_1 = Container('frame-1',
                                x=self.left_margin,
                                y=self.bottom_margin+self.height*(2/3),
                                width=self.width/2,
                                height=self.height*(1/3))
        container_2 = Container('frame-2',
                                x=self.page_width/2,
                                y=self.bottom_margin+self.height*(2/3),
                                width=self.width/2,
                                height=self.height*(1/3))
        container_3 = Container('frame-3',
                                x=self.left_margin,
                                y=self.bottom_margin,
                                width=self.width,
                                height=self.height*(2/3))
        self.add_containers([container_1, container_2, container_3])
        headers = self.create_headers()
        self.add_headers(headers)
        footers = self.create_footers()
        self.add_footers(footers)


class Template3(BaseLayout):
    """A basic template with one Container."""
    def __init__(self, identifier: str, page_size: Tuple[float, float],
                 left_margin: float, right_margin: float, bottom_margin: float,
                 top_margin: float):
        BaseLayout.__init__(self, identifier, page_size, left_margin,
                            right_margin, bottom_margin, top_margin)
        container = Container('frame-1',
                              x=self.left_margin,
                              y=self.bottom_margin,
                              width=self.width,
                              height=self.height)
        self.add_containers(container)
