"""Module for Tables."""
from typing import List, Union
import pandas as pd

from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, Paragraph

from pollination_pdf_reports.styles import STYLES


ROWBACKGROUNDS = [
    colors.Color(253 / 255, 253 / 255, 253 / 255),
    colors.Color(248 / 255, 248 / 255, 248 / 255)
]


class TableWrapper:
    """Wrapper for ReportLab Tables."""
    __slots__ = ('_df', '_data', '_exclude_columns', '_col_widths',
                 '_row_heights', '_row_backgrounds', '_global_styles')
    def __init__(
            self, df: Union[pd.DataFrame, list],
            col_widths: list = None, row_heights: list = None,
            exclude_columns: list = None,
            row_backgrounds: List[colors.Color] = ROWBACKGROUNDS):
        """Initializes the TableWrapper with data, column widths, and row heights."""
        if isinstance(df, pd.DataFrame):
            self.df = df
        elif isinstance(df, list):
            self.df = pd.DataFrame(df[1:], columns=df[0])
        else:
            raise TypeError('Data must be a Pandas DataFrame or a list of lists.')

        header = [{'data': col, 'commands': []} for col in self.df.columns]
        data = self.df.map(lambda x: {'data': x, 'commands': []}).values.tolist()
        self.data = [header] + data

        self.exclude_columns = exclude_columns if exclude_columns else []
        self.col_widths = col_widths
        self.row_heights = row_heights
        self.global_styles = [
            ('LINEBELOW', (0, 0), (-1, 0), 1, colors.black),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold')
        ]
        if row_backgrounds:
            self.global_styles.append(('ROWBACKGROUNDS', (0, 1), (-1, -1), row_backgrounds))

    @property
    def df(self) -> pd.DataFrame:
        """Return DataFrame of original data."""
        return self._df

    @df.setter
    def df(self, df):
        if not isinstance(df, pd.DataFrame):
            raise TypeError('df must be an instance of DataFrame.')
        self._df = df

    @property
    def data(self) -> list:
        """Return table data with commands for styling."""
        return self._data

    @data.setter
    def data(self, data):
        self._data = data

    @property
    def exclude_columns(self) -> list:
        """Return excluded columns."""
        return self._exclude_columns

    @exclude_columns.setter
    def exclude_columns(self, exclude_columns):
        self._exclude_columns = exclude_columns

    @property
    def col_widths(self) -> list:
        """Return column widths."""
        return self._col_widths

    @col_widths.setter
    def col_widths(self, col_widths):
        self._col_widths = col_widths

    @property
    def row_heights(self) -> list:
        """Return row heights."""
        return self._row_heights

    @row_heights.setter
    def row_heights(self, row_heights):
        self._row_heights = row_heights

    @property
    def global_styles(self) -> list:
        """Return list of TableStyle commands."""
        return self._global_styles

    @global_styles.setter
    def global_styles(self, global_styles):
        self._global_styles = global_styles

    def add_style(self, *style_commands):
        """Add global style commands."""
        self.global_styles.extend(style_commands)

    def apply_global_styles(self):
        """Apply the accumulated styles to the table."""
        return TableStyle(self.global_styles)

    def sort_by_column(self, col_name: str, ascending: bool = False):
        """Sort the table data (excluding headers) by a specific column name."""
        df = self.rebuild_dataframe()
        if col_name not in df.columns:
            raise ValueError(f'Column "{col_name}" not found in DataFrame.')

        sorted_df = df.sort_values(by=col_name, ascending=ascending)
        sorted_df.index.to_list()

        reordered_data = [self.data[0]] + [self.data[i + 1] for i in sorted_df.index.to_list()]
        self.data = reordered_data

    def rebuild_dataframe(self) -> pd.DataFrame:
        """Rebuild a DataFrame."""
        columns = [item['data'] for item in self.data[0]]
        rows = [[item['data'] for item in row] for row in self.data[1:]]
        df = pd.DataFrame(rows, columns=columns)

        return df

    def add_conditional_coloring(
            self, column_name: str, condition_color_map,
            type_column: str = None, type_value_condition: str = None):
        """Apply conditional coloring to a column, optionally based on row's type."""
        df = self.rebuild_dataframe()
        if column_name not in df.columns:
            raise ValueError(f"Column '{column_name}' not found in DataFrame.")

        column_index = df.columns.get_loc(column_name)
        for row_index, row in enumerate(df.itertuples(index=False), start=1):
            if type_column and row[df.columns.get_loc(type_column)] != type_value_condition:
                continue  # Skip row if it doesn't match the type condition
            
            for condition_func, color in condition_color_map:
                if condition_func(row[column_index]):  # If condition is met, apply color
                    self.data[row_index][column_index]['commands'].append(
                        ('BACKGROUND', (None, None), (None, None), color)
                    )
                    break

    def build(self, filter_column: str = None, filter_values: list = None,
              exclude_columns: list = None, **kwargs):
        """Builds and returns the ReportLab Table object with applied styles."""
        exclude_columns = exclude_columns if exclude_columns is not None else self.exclude_columns
        exclude_indices = {
            i for i, col in enumerate(self.data[0])
            if col['data'] in exclude_columns
        }

        if filter_column and filter_values is not None:
            df = self.rebuild_dataframe()
            if filter_column not in df.columns:
                raise ValueError(f'Column "{filter_column}" not found in DataFrame.')

            valid_indices = df[df[filter_column].isin(filter_values)].index.tolist()
            filtered_data = [self.data[0]] + [self.data[i + 1] for i in valid_indices]
        else:
            filtered_data = self.data

        filtered_data = [
            [cell for i, cell in enumerate(row) if i not in exclude_indices]
            for row in filtered_data
        ]

        table_data = []
        styles = []
        for row_index, row in enumerate(filtered_data):
            row_data = []
            for column_index, cell in enumerate(row):
                style = STYLES['Normal_8_BOLD'] if row_index == 0 else STYLES['Normal_8']
                row_data.append(Paragraph(str(cell['data']), style=style))
                for cmd in cell['commands']:
                    cmd = (cmd[0], (column_index, row_index), (column_index, row_index), cmd[3])
                    styles.append(cmd)
            table_data.append(row_data)

        table = Table(table_data, repeatRows=1, **kwargs)
        table.setStyle(TableStyle(self.global_styles + styles))

        return table
