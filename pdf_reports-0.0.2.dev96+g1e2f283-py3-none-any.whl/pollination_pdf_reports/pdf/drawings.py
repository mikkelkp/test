import numpy as np
from enum import Enum

from reportlab.lib import colors
from reportlab.graphics.shapes import Drawing, Polygon, Circle, String, Line

from honeybee.model import Room
from ladybug.legend import Legend
from honeybee_radiance.sensorgrid import SensorGrid

from pollination_pdf_reports.helper.drawings import merge_drawings


class ViewOrientation(Enum):
    NE = 'NE'
    SE = 'SE'
    SW = 'SW'
    NW = 'NW'


ISOMETRICPROJECTMATRIX = {
    ViewOrientation.NE: np.array([
        [-np.sqrt(2) / 2, np.sqrt(2) / 2, 0, 0],
        [-1 / np.sqrt(6), -1 / np.sqrt(6), 2 / np.sqrt(6), 0],
        [0, 0, 0, 0],
        [0, 0, 0, 1]
    ]),
    ViewOrientation.SE: np.array([
        [np.sqrt(2) / 2, np.sqrt(2) / 2, 0, 0],
        [-1 / np.sqrt(6), 1 / np.sqrt(6), 2 / np.sqrt(6), 0],
        [0, 0, 0, 0],
        [0, 0, 0, 1]
    ]),
    ViewOrientation.SW: np.array([
        [np.sqrt(2) / 2, -np.sqrt(2) / 2, 0, 0],
        [1 / np.sqrt(6), 1 / np.sqrt(6), 2 / np.sqrt(6), 0],
        [0, 0, 0, 0],
        [0, 0, 0, 1]
    ]),
    ViewOrientation.NW: np.array([
        [-np.sqrt(2) / 2, -np.sqrt(2) / 2, 0, 0],
        [1 / np.sqrt(6), -1 / np.sqrt(6), 2 / np.sqrt(6), 0],
        [0, 0, 0, 0],
        [0, 0, 0, 1]
    ])
}


class DrawingLegend(object):
    """DrawingLegend converts a Ladybug Legend to a ReportLab Drawing."""
    __slots__ = ('_legend',)
    def __init__(self, legend: Legend):
        self.legend = legend

    @property
    def legend(self) -> Legend:
        """Return Ladybug Legend."""
        return self._legend

    @legend.setter
    def legend(self, legend):
        if not isinstance(legend, Legend):
            raise TypeError('legend must be an instance of Legend.')
        self._legend = legend

    def draw_legend(self, hAlign: str = 'LEFT') -> Drawing:
        """Create a ReportLab Drawing of a Ladybug Legend.
        
        Args:
            hAlign: Horizontal alignment of the Drawing. Chose between "LEFT",
                "CENTER", and "RIGHT".

        Returns:
            A ReportLab Drawing of a Ladybug Legend.
        """
        legend = self.legend

        drawing = Drawing(0, 0)
        drawing.hAlign = hAlign
        font_size = legend.legend_parameters.text_height

        # create legend mesh
        for face, segment_color in \
            zip(legend.segment_mesh_scene_2d.face_vertices,
                legend.segment_colors):
            points = []
            fillColor = colors.Color(segment_color.r/255, segment_color.g/255,
                                     segment_color.b/255)
            for vertex in face:
                points.extend([vertex.x, vertex.y])
            polygon = Polygon(points=points, fillColor=fillColor, strokeWidth=0,
                              strokeColor=fillColor)
            drawing.add(polygon)

        # create legend segment text
        for segment_text, segment_text_location in \
            zip(legend.segment_text, legend.segment_text_location):
            stl_x = segment_text_location.o.x
            stl_y = segment_text_location.o.y

            string = String(x=stl_x, y=stl_y, text=str(segment_text),
                            textAnchor='start', fontName='Helvetica',
                            fontSize=font_size, strokeColor=colors.black)
            drawing.add(string)

        tl_x = legend.title_location.o.x
        tl_y = legend.title_location.o.y
        string = String(x=tl_x, y=tl_y, text=legend.title,
                        textAnchor='start', fontName='Helvetica',
                        fontSize=font_size)
        drawing.add(string)

        return drawing


class DrawingRoom(object):
    """DrawingLegend converts a Honeybee Room to a ReportLab Drawing."""
    __slots__ = ('_room', '_sensor_grid')
    def __init__(self, room: Room, sensor_grid: SensorGrid = None):
        self.room = room
        self.sensor_grid = sensor_grid

    @property
    def room(self) -> Room:
        """Return Room."""
        return self._room

    @room.setter
    def room(self, room):
        if not isinstance(room, Room):
            raise TypeError('room must be an instance of Room.')
        self._room = room

    @property
    def sensor_grid(self) -> SensorGrid:
        """Return SensorGrid"""
        return self._sensor_grid

    @sensor_grid.setter
    def sensor_grid(self, sensor_grid):
        if sensor_grid is not None and not isinstance(sensor_grid, SensorGrid):
            raise TypeError('sensor_grid must be an instance of SensorGrid or None.')
        self._sensor_grid = sensor_grid

    def draw_room(
        self, stroke_width: float = 0.2, hAlign: str = 'LEFT', fill_color: colors.Color = None,
        fill_opacity: float = 0, stroke_color: colors.Color = colors.Color(0, 0, 0), display_name: bool = False, draw_apertures: bool = False
    ) -> Drawing:
        """Create a ReportLab Drawing of a Honeybee Room.
        
        Args:
            stroke_width: Stroke width of the room boundary.
            hAlign: Horizontal alignment of the Drawing. Chose between "LEFT",
                "CENTER", and "RIGHT".
            display_name: If True the Room display name will be added to the
                Drawing.
            draw_apertures: If True the Apertures in the Room will be added on
                top of the Room boundary. Only vertical Apertures will be drawn.
                The color of the Apertures is blue.

        Returns:
            A ReportLab Drawing of a Honeybee Room.
        """
        drawing = Drawing(0, 0)
        drawing.hAlign = hAlign
        horiz_bound = self.room.horizontal_boundary()

        points = []
        for vertex in horiz_bound.vertices:
            points.extend([vertex.x, vertex.y])
        polygon = Polygon(points=points, strokeWidth=stroke_width, fillColor=fill_color, fillOpacity=fill_opacity, strokeColor=stroke_color)
        drawing.add(polygon)

        if display_name:
            # only room center supported for now
            room_center = self.room.center
            string = String(x=room_center.x, y=room_center.y,
                            text=self.room.display_name, textAnchor='middle',
                            fontName='Helvetica', fontSize=2)
            drawing.add(string)

        if draw_apertures:
            for aperture in self.room.apertures:
                if aperture.normal.z == 0:
                    aperture_min = aperture.geometry.lower_left_corner
                    aperture_max = aperture.geometry.lower_right_corner
                    strokeColor = colors.Color(95 / 255, 195 / 255, 255 / 255)
                    line = Line(aperture_min.x, aperture_min.y, aperture_max.x, aperture_max.y,
                                strokeColor=strokeColor,
                                strokeWidth=stroke_width
                                )
                    drawing.add(line)

        return drawing

    def draw_heatmap(
        self, values: list, legend: Legend, stroke_width: float = 0.2,
        as_circle: bool = False, hAlign: str = 'LEFT', display_name:
        bool = False, draw_apertures: bool = False
    ) -> Drawing:
        """Create a ReportLab Drawing of a Honeybee Room with a heatmap.
        
        Args:
            values: A list of numeric values for each sensor point.
            legend: A Ladybug Legend. This is used to extract the colors for
                the heatmap.
            stroke_width: Stroke width of the room boundary.
            as_circles: If True the sensor points will be represented as circles
                rather than rectangles.
            hAlign: Horizontal alignment of the Drawing. Chose between "LEFT",
                "CENTER", and "RIGHT".
            display_name: If True the Room display name will be added to the
                Drawing.
            draw_apertures: If True the Apertures in the Room will be added on
                top of the Room boundary. Only vertical Apertures will be drawn.
                The color of the Apertures is blue.

        Returns:
            A ReportLab Drawing of a Honeybee Room with a heatmap.
        """
        if self.sensor_grid is None:
            raise ValueError('sensor_grid is not set. Cannot draw heatmap.')

        drawing = Drawing(0, 0)
        drawing.hAlign = hAlign
        faces = self.sensor_grid.mesh.faces
        faces_centroids = self.sensor_grid.mesh.face_centroids
        for face, face_centroid, value in zip(faces, faces_centroids, values):
            vertices = [self.sensor_grid.mesh[i] for i in face]
            points = []
            max_x, min_x, max_y, min_y = float('-inf'), float('inf'), float('-inf'), float('inf')
            for vertex in vertices:
                points.extend([vertex.x, vertex.y])
                if vertex.x > max_x:
                    max_x = vertex.x
                if vertex.x < min_x:
                    min_x = vertex.x
                if vertex.y > max_y:
                    max_y = vertex.y
                if vertex.y < min_y:
                    min_y = vertex.y

            circle_diameter = min([max_x - min_x, max_y - min_y])

            lb_color =  legend.color_range.color(value)
            fillColor = colors.Color(lb_color.r / 255, lb_color.g / 255, lb_color.b / 255)
            if not as_circle:
                shape = Polygon(points=points, fillColor=fillColor,
                                strokeColor=fillColor, strokeWidth=0)
            else:
                shape = Circle(
                    face_centroid.x, face_centroid.y, circle_diameter / 2 * 0.75,
                    fillColor=fillColor, strokeColor=fillColor, strokeWidth=0)
            drawing.add(shape)

        drawing_room = self.draw_room(
            stroke_width=stroke_width, hAlign=hAlign,
            display_name=display_name, draw_apertures=draw_apertures)
        drawing = merge_drawings([drawing, drawing_room])

        return drawing

    def draw_sensor_grid(
        self, stroke_width: float = 0.2, as_circle: bool = False,
        hAlign: str = 'LEFT', display_name: bool = False,
        draw_apertures: bool = False
    ) -> Drawing:
        """Create a ReportLab Drawing of a Honeybee Room with a sensor grid.
        
        Args:
            stroke_width: Stroke width of the room boundary.
            as_circles: If True the sensor points will be represented as circles
                rather than rectangles.
            hAlign: Horizontal alignment of the Drawing. Chose between "LEFT",
                "CENTER", and "RIGHT".
            display_name: If True the Room display name will be added to the
                Drawing.
            draw_apertures: If True the Apertures in the Room will be added on
                top of the Room boundary. Only vertical Apertures will be drawn.
                The color of the Apertures is blue.

        Returns:
            A ReportLab Drawing of a Honeybee Room with a sensor grid.
        """
        if self.sensor_grid is None:
            raise ValueError('sensor_grid is not set. Cannot draw sensor grid.')

        drawing = Drawing(0, 0)
        drawing.hAlign = hAlign
        faces = self.sensor_grid.mesh.faces
        faces_centroids = self.sensor_grid.mesh.face_centroids
        for face, face_centroid in zip(faces, faces_centroids):
            vertices = [self.sensor_grid.mesh[i] for i in face]
            points = []
            max_x, min_x, max_y, min_y = float('-inf'), float('inf'), float('-inf'), float('inf')
            for vertex in vertices:
                points.extend([vertex.x, vertex.y])
                if vertex.x > max_x:
                    max_x = vertex.x
                if vertex.x < min_x:
                    min_x = vertex.x
                if vertex.y > max_y:
                    max_y = vertex.y
                if vertex.y < min_y:
                    min_y = vertex.y

            circle_diameter = min([max_x - min_x, max_y - min_y])

            if not as_circle:
                shape = Polygon(points=points, fillColor=colors.Color(175/255, 175/255, 175/255),
                                strokeColor=colors.Color(175/255, 175/255, 175/255), strokeWidth=0)
            else:
                shape = Circle(
                    face_centroid.x, face_centroid.y, circle_diameter / 2 * 0.75,
                    fillColor=colors.Color(175/255, 175/255, 175/255), strokeColor=colors.Color(175/255, 175/255, 175/255), strokeWidth=0)
            drawing.add(shape)

        drawing_room = self.draw_room(
            stroke_width=stroke_width, hAlign=hAlign,
            display_name=display_name, draw_apertures=draw_apertures)
        drawing = merge_drawings([drawing, drawing_room])

        return drawing

    def draw_room_isometric(
        self, orientation: ViewOrientation = ViewOrientation.SE,
        apertures: list = None, dynamic_group_identifier: str = None
    ) -> Drawing:
        """Create a ReportLab Drawing of a Honeybee Room in isometric projection.
        
        Args:
            orientation: Orientation of the view point. "NE", "SE", "SW", or "NW"
                are the valid options.
            apertures: A list of Aperture display names. If an Aperture is in
                this list the Aperture color will be blue.
            dynamic_group_identifier: A dynamic group identifier. If an Aperture
                has this identifier as its dynamic group identifier the Aperture
                color will be blue.

        Returns:
            A ReportLab Drawing of a Honeybee Room in isometric projection.
        """
        room = self.room.duplicate()
        try:
            room.merge_coplanar_faces()
        except Exception:
            pass

        drawing_3d = Drawing(0, 0)

        points_projected = []
        faces_projected = []
        apertures_projected = {}
        for face in room.faces:
            face_projected = []
            for vertex in face.vertices:
                point_3d = np.array(vertex.to_array())
                point_3d = np.append(point_3d, 1)

                projected_coordinates = np.dot(ISOMETRICPROJECTMATRIX[orientation], point_3d)
                face_projected.append(
                    [projected_coordinates[0], projected_coordinates[1]]
                )
            faces_projected.append(face_projected)
            points_projected.extend(face_projected)

            for aperture in face.apertures:
                aperture_projected = []
                for vertex in aperture.vertices:
                    point_3d = np.array(vertex.to_array())
                    point_3d = np.append(point_3d, 1)
                    projected_coordinates = np.dot(ISOMETRICPROJECTMATRIX[orientation], point_3d)
                    aperture_projected.append(
                        [projected_coordinates[0], projected_coordinates[1]]
                    )
                if aperture.properties.radiance.dynamic_group_identifier and \
                    aperture.properties.radiance.dynamic_group_identifier == dynamic_group_identifier:
                    apertures_projected[aperture.identifier] = {
                        'points': aperture_projected,
                        'fillColor': colors.Color(95 / 255, 195 / 255, 255 / 255),
                        'strokeColor': colors.Color(95 / 255, 195 / 255, 255 / 255)
                    }
                elif apertures and aperture.display_name in apertures:
                    apertures_projected[aperture.identifier] = {
                        'points': aperture_projected,
                        'fillColor': colors.Color(95 / 255, 195 / 255, 255 / 255),
                        'strokeColor': colors.Color(95 / 255, 195 / 255, 255 / 255)
                    }
                else:
                    apertures_projected[aperture.identifier] = {
                        'points': aperture_projected,
                        'fillColor': colors.Color(220 / 255, 220 / 255, 220 / 255),
                        'strokeColor': colors.Color(220 / 255, 220 / 255, 220 / 255)
                    }

                points_projected.extend(aperture_projected)

        for aperture_data in apertures_projected.values():
            points = []
            for vertex in aperture_data['points']:
                points.extend([vertex[0], vertex[1]])
            drawing_3d.add(
                Polygon(points, fillColor=aperture_data['fillColor'],
                        strokeColor=aperture_data['strokeColor'], strokeWidth=0.1,
                        fillOpacity=0.3, strokeLineJoin=1))
        for face in faces_projected:
            points = []
            for vertex in face:
                points.extend([vertex[0], vertex[1]])

            drawing_3d.add(Polygon(points, strokeWidth=0.1, fillOpacity=0, strokeLineJoin=1))

        return drawing_3d
