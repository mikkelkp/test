import pandas as pd
from typing import List

from reportlab.lib import colors
from reportlab.platypus import Paragraph, Table, TableStyle

from pollination_pdf_reports.styles import STYLES


ROWBACKGROUNDS = [
    colors.Color(248 / 255, 248 / 255, 248 / 255),
    colors.Color(253 / 255, 253 / 255, 253 / 255)
]


def table_from_dataframe(
        dataframe: pd.DataFrame, rowbackgrounds: List[colors.Color] = ROWBACKGROUNDS,
        bold_header: bool = True
        ) -> Table:
    """Create a ReportLab Table from a Pandas DataFrame.
    
    Args:
        dataframe: Pandas DataFrame.
        rowbackgrounds: A list of colors to use as row background colors. A
            repeating pattern of colors can be achieved by using a list of
            colors.
        bold_header: Boolean to note whether or not to use bold text for the
            first row in the Table. (Default: True).
    """
    table_data =  [tuple(dataframe)] + list(dataframe.itertuples(index=False, name=None))

    table_style = TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('LINEBELOW', (0, 0), (-1, 0), 0.2, colors.black)
    ])
    if rowbackgrounds is not None:
        table_style.add('ROWBACKGROUNDS', (0, 1), (-1, -1), rowbackgrounds)

    formatted_table_data = []
    for idx_row, row in enumerate(table_data):
        formatted_row = []
        for idx_cell, cell_value in enumerate(row):
            if idx_row == 0:
                if bold_header:
                    formatted_row.append(Paragraph(str(cell_value), style=STYLES['Normal_BOLD']))
                else:
                    formatted_row.append(Paragraph(str(cell_value), style=STYLES['Normal']))
            else:
                formatted_row.append(Paragraph(str(cell_value), style=STYLES['Normal']))
        formatted_table_data.append(formatted_row)

    table = Table(
        formatted_table_data, colWidths='*', repeatRows=1, rowSplitRange=0,
        spaceBefore=5, spaceAfter=5
    )
    table.setStyle(table_style)

    return table
