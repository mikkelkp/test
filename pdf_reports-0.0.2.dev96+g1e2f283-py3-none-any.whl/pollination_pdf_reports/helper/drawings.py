"""Module with helper functions for ReportLab Drawings."""
from typing import Union, List, Tuple
from enum import Enum
from copy import deepcopy
import numpy as np

from reportlab.graphics.shapes import Drawing, Polygon, String, Circle, PolyLine, \
    Line, Group, Rect, Path, Image
from reportlab.lib import colors


class PointParameters(Enum):
    NORTH = (0.5, 1)
    NORTHEAST = (1, 1)
    EAST = (1, 0.5)
    SOUTHEAST = (1, 0)
    SOUTH = (0.5, 0)
    SOUTHWEST = (0, 0)
    WEST = (0, 0.5)
    NORTHWEST = (0, 1)


def drawing_dimensions_from_bounds(drawing: Drawing):
    """Set the width and height based on the boundaries of the contents.

    This function will not return a new Drawing, but will instead edit the input
    Drawing object.

    This function will also translate the contents of the Drawing to origin
    (0, 0) if they are not already at origin.

    Args:
        drawing: A ReportLab Drawing object.
    """
    drawing_bounds = drawing.getBounds()
    if drawing_bounds[0] != 0 or drawing_bounds[1] != 0:
        dx = 0 - drawing_bounds[0]
        dy = 0 - drawing_bounds[1]
        drawing.translate(dx, dy)
    drawing.width = abs(drawing_bounds[2] - drawing_bounds[0])
    drawing.height = abs(drawing_bounds[3] - drawing_bounds[1])


def translation_vector_from_drawing(
    drawing: Drawing, point: Union[List[float], Tuple[float]] = (0, 0),
    from_point: Union[List[float], Tuple[float]] = None
    ) -> tuple[float, float]:
    """Get dx and dy to translate Drawing contents to a point.

    The drawing object itself has a method to translate contents, however, it is
    not possible to apply multiple transforms, e.g., translate and then scale.
    This function might be useful in such cases to return the dx and dy
    translation vector that can be used to translate contents of a drawing, and
    then apply the scale afterward.
    
    Args:
        drawing: A ReportLab Drawing object.
        point: A list or tuple with the x and y coordinates to translate contents
            to. This is (0, 0) by default.
        from_point: A list or tuple with x and y coordinates from where to
            translate from. The default is None meaning that will use the
            minimum x and y values of the Drawing contents.

    Returns:
        A tuple of floats of the translation vector (dx, dy).
    """
    drawing_bounds = drawing.getBounds()
    if from_point is not None:
        drawing_bounds = (from_point[0], from_point[1])
    dx = point[0] - drawing_bounds[0]
    dy = point[1] - drawing_bounds[1]
    return dx, dy


def translate_points(points: list, dx: float, dy: float) -> list:
    """Translate a list of points by a vector.

    The points must be in the form [x1, y1, x2, y2, ..., xn, yn]. This is how
    the points are presented in ReportLab.
    
    Args:
        points: A list of points from a ReportLab Shape objects.
        dx: Translation of x-coordinates.
        dy: Translation of y-coordinates.
    
    Returns:
        A list of translated points.
    """
    assert len(points) % 2 == 0, 'Point list must have even number of elements!'
    points = np.array(points)
    reshaped_points = points.reshape(-1, 2)
    translated_points = (reshaped_points + [dx, dy]).ravel().tolist()

    return translated_points


def scale_points(points: list, sx: float, sy: float) -> list:
    """Scale a list of points by a scaling factor.

    The points must be in the form [x1, y1, x2, y2, ..., xn, yn]. This is how
    the points are presented in ReportLab.
    
    Args:
        points: A list of points from a ReportLab Shape objects.
        sx: Scaling factor for the x-coordinates.
        sy: Scaling factor for the y-coordinates.
    
    Returns:
        A list of scaled points.
    """
    assert len(points) % 2 == 0, 'Point list must have even number of elements!'
    points = np.array(points)
    reshaped_points = points.reshape(-1, 2)
    scaled_points = (reshaped_points * [sx, sy]).ravel().tolist()

    return scaled_points


def rotate_points(points: list, degrees: float) -> list:
    """Rotate a list of points by degrees.

    The points must be in the form [x1, y1, x2, y2, ..., xn, yn]. This is how
    the points are presented in ReportLab.
    
    Args:
        points: A list of points from a ReportLab Shape objects.
        degrees: Rotation angle in degrees. A positive value will rotate the
            points clockwise.
    
    Returns:
        A list of rotated points.
    """
    assert len(points) % 2 == 0, 'Point list must have even number of elements!'
    points = np.array(points)
    reshaped_points = points.reshape(-1, 2)
    angle_rad = np.radians(degrees)
    rotation_matrix = np.array([
        [np.cos(angle_rad), np.sin(angle_rad)],
        [-np.sin(angle_rad), np.cos(angle_rad)]
    ])
    rotated_points = (reshaped_points @ rotation_matrix.T).ravel().tolist()

    return rotated_points


def translate_content(content, dx: float, dy: float):
    if isinstance(content, Polygon):
        translated_points = translate_points(content.points, dx=dx, dy=dy)
        content.points = translated_points
    elif isinstance(content, String):
        x, y = translate_points([content.x, content.y], dx=dx, dy=dy)
        content.x = x
        content.y = y
    elif isinstance(content, Circle):
        x, y = translate_points([content.cx, content.cy], dx=dx, dy=dy)
        content.cx = x
        content.cy = y
    elif isinstance(content, PolyLine):
        translated_points = translate_points(content.points, dx=dx, dy=dy)
        content.points = translated_points
    elif isinstance(content, Rect):
        points = content.x, content.y
        translated_points = translate_points(points, dx=dx, dy=dy)
        content.x, content.y = translated_points
    elif isinstance(content, Line):
        points = content.x1, content.y1, content.x2, content.y2
        translated_points = translate_points(points, dx=dx, dy=dy)
        content.x1, content.y1, content.x2, content.y2 = translated_points
    elif isinstance(content, Path):
        translated_points = translate_points(content.points, dx=dx, dy=dy)
        content.points = translated_points
    elif isinstance(content, Group):
        for sub_content in content.contents:
            translate_content(sub_content, dx, dy)
    else:
        raise NotImplementedError(f'{type(content)} is not yet implemented.')


def scale_content(content, scaling_factor: float, stroke_width: bool = True):
    if isinstance(content, Polygon):
        scaled_points = scale_points(content.points, scaling_factor, scaling_factor)
        content.points = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, Circle):
        points = content.cx, content.cy
        cx, cy = scale_points(points, scaling_factor, scaling_factor)
        content.cx, content.cy = cx, cy
        content.r *= scaling_factor
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, String):
        x, y = scale_points([content.x, content.y], scaling_factor, scaling_factor)
        content.x, content.y = x, y
        content.fontSize = content.fontSize * scaling_factor
    elif isinstance(content, Line):
        points = content.x1, content.y1, content.x2, content.y2
        scaled_points = scale_points(points, scaling_factor, scaling_factor)
        content.x1, content.y1, content.x2, content.y2 = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, PolyLine):
        scaled_points = scale_points(content.points, scaling_factor, scaling_factor)
        content.points = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, Rect):
        points = content.x, content.y
        content.width *= scaling_factor
        content.height *= scaling_factor
        scaled_points = scale_points(points, scaling_factor, scaling_factor)
        content.x, content.y = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, Image):
        points = content.x, content.y
        content.width *= scaling_factor
        content.height *= scaling_factor
        scaled_points = scale_points(points, scaling_factor, scaling_factor)
        content.x, content.y = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor     
    elif isinstance(content, Path):
        scaled_points = scale_points(content.points, scaling_factor, scaling_factor)
        content.points = scaled_points
        if stroke_width:
            content.strokeWidth *= scaling_factor
    elif isinstance(content, Group):
        for sub_content in content.contents:
            scale_content(sub_content, scaling_factor, stroke_width=stroke_width)
    else:
        raise NotImplementedError(f'{type(content)} is not yet implemented.')


def translate_drawing_contents(drawing: Drawing, dx: float, dy: float) -> Drawing:
    """Translate all contents in a Drawing.
    
    Args:
        drawing: A ReportLab Drawing object.
        dx: Translation of x-coordinates.
        dy: Translation of y-coordinates.

    Returns:
        A ReportLab Drawing with all contents translated.
    """
    new_drawing = deepcopy(drawing)
    for content in new_drawing.contents:
        translate_content(content, dx, dy)

    return new_drawing


def translate_drawing_contents_to_origin(drawing: Drawing) -> Drawing:
    """Translate all contents in a Drawing to origin.

    Args:
        drawing: A ReportLab Drawing object.

    Returns:
        A ReportLab Drawing with all contents translated to origin.
    """
    dx, dy = translation_vector_from_drawing(drawing, point=(0, 0))
    new_drawing = translate_drawing_contents(drawing, dx, dy)

    return new_drawing


def scale_drawing_contents(
        drawing: Drawing, scaling_factor: float, stroke_width: bool = True
    ) -> Drawing:
    """Scale all contents in a Drawing.

    This function only has one scaling factor, which means that the scaling
    will be uniform for both x- and y-coordinates.

    The width of strokes will also be scaled by the scaling factor if
    stroke_width is True.
    
    Args:
        drawing: A ReportLab Drawing object.
        scaling_factor: Scaling factor for the coordinates.
        stroke_width: Boolean to note whether or not to scale the stroke width
            of the Shapes. (Default: True).

    Returns:
        A ReportLab Drawing with all contents scaled.
    """
    new_drawing = deepcopy(drawing)
    contents = new_drawing.getContents()
    for content in contents:
        if isinstance(content, Polygon):
            scaled_points = scale_points(content.points, scaling_factor, scaling_factor)
            content.points = scaled_points
            if stroke_width:
                content.strokeWidth *= scaling_factor
        else:
            raise NotImplementedError(f'{type(content)} is not yet implemented.')

    return new_drawing


def scale_drawing_contents_to_width(
        drawing: Drawing, width: float, max_height: float = None,
        stroke_width: bool = True
    ) -> Drawing:
    """Scale all contents in a Drawing to a specific width.

    The scaling will be proportionate.

    The width of strokes will also be scaled if stroke_width is True.
    
    Args:
        drawing: A ReportLab Drawing object.
        width: Width of the new Drawing contents.
        max_height: Maximum height of the new Drawing contents.
        stroke_width: Boolean to note whether or not to scale the stroke width
            of the Shapes. (Default: True).

    Returns:
        A ReportLab Drawing with all contents scaled.
    """
    contents_width = get_drawing_width(drawing)
    contents_height = get_drawing_height(drawing)

    new_drawing = deepcopy(drawing)
    scaling_factor = width / contents_width
    new_height = contents_height * scaling_factor
    if max_height is not None and new_height > max_height:
        scaling_factor = max_height / contents_height
    for content in new_drawing.contents:
        scale_content(content, scaling_factor, stroke_width=stroke_width)

    drawing_dimensions_from_bounds(new_drawing)

    return new_drawing


def scale_drawing_contents_to_height(
        drawing: Drawing, height: float, max_width: float = None,
        stroke_width: bool = True
    ) -> Drawing:
    """Scale all contents in a Drawing to a specific height.

    The scaling will be proportionate.

    The width of strokes will also be scaled if stroke_width is True.
    
    Args:
        drawing: A ReportLab Drawing object.
        height: Height of the new Drawing contents.
        max_width: Maximum width of the new Drawing contents.
        stroke_width: Boolean to note whether or not to scale the stroke width
            of the Shapes. (Default: True).

    Returns:
        A ReportLab Drawing with all contents scaled.
    """
    contents_width = get_drawing_width(drawing)
    contents_height = get_drawing_height(drawing)

    new_drawing = deepcopy(drawing)
    scaling_factor = height / contents_height
    new_width = contents_width * scaling_factor
    if max_width is not None and new_width > max_width:
        scaling_factor = max_width / contents_width
    for content in new_drawing.contents:
        if isinstance(content, Polygon):
            scaled_points = scale_points(content.points, scaling_factor, scaling_factor)
            content.points = scaled_points
            if stroke_width:
                content.strokeWidth *= scaling_factor
        elif isinstance(content, String):
            x, y = scale_points([content.x, content.y], scaling_factor, scaling_factor)
            content.x, content.y = x, y
            content.fontSize = content.fontSize * scaling_factor
        elif isinstance(content, Line):
            points = content.x1, content.y1, content.x2, content.y2
            scaled_points = scale_points(points, scaling_factor, scaling_factor)
            content.x1, content.y1, content.x2, content.y2 = scaled_points
        else:
            raise NotImplementedError(f'{type(content)} is not yet implemented.')

    drawing_dimensions_from_bounds(new_drawing)

    return new_drawing


def merge_drawings(drawings: List[Drawing], hAlign: str = 'LEFT') -> Drawing:
    """Merge multiple Drawings.

    This function will take all the contents from the input Drawings and add
    them to a new Drawing.
    
    Args:
        drawing: A ReportLab Drawing object.
        hAlign: Horizontal alignment of the new Drawing. Valid options are
        LEFT, CENTER/CENTRE, and RIGHT.

    Returns:
        A ReportLab Drawing with all the contents of the Drawings.
    """
    new_drawing = Drawing(0, 0)
    new_drawing.hAlign = hAlign
    for drawing in drawings:
        for content in drawing.contents:
            new_drawing.add(content)

    return new_drawing


def get_drawing_width(drawing: Drawing) -> float:
    """Get the width of all contents in a Drawing.
    
    Args:
        drawing: A ReportLab Drawing object.

    Returns:
        A float value of the width of all contents in the Drawing.
    """
    drawing_bounds = drawing.getBounds()
    return drawing_bounds[2] - drawing_bounds[0]


def get_drawing_height(drawing: Drawing) -> float:
    """Get the height of all contents in a Drawing.
    
    Args:
        drawing: A ReportLab Drawing object.

    Returns:
        A float value of the height of all contents in the Drawing.
    """
    drawing_bounds = drawing.getBounds()
    return drawing_bounds[3] - drawing_bounds[1]


def get_point_at_parameters(
        drawing: Drawing, parameters: Union[List[float], Tuple[float]] = (0, 0)
        ) -> tuple:
    """Get a point at parameters based on Drawing contents.
    
    Args:
        drawing: A ReportLab Drawing object.
        parameters: A list or tuple with parameter values for x and y. E.g.,
            (0.5, 0.5) will return the center point of the Drawing contents.

    Returns:
        A tuple of the point at parameters.
    """
    drawing_bounds = drawing.getBounds()
    point = (
        np.interp(parameters[0], [0, 1], [drawing_bounds[0], drawing_bounds[2]]),
        np.interp(parameters[1], [0, 1], [drawing_bounds[1], drawing_bounds[3]])
    )
    return point


def add_drawing_at(
        base_drawing: Drawing, add_drawing: Drawing,
        base_anchor: PointParameters = PointParameters.SOUTH,
        add_anchor: PointParameters = PointParameters.NORTH,
        pad: float = 0
        ) -> Drawing:
    """Add a Drawing to another Drawing.

    Args:
        base_drawing: A ReportLab Drawing object.
        add_drawing: A ReportLab Drawing object to add to the base Drawing.
        base_anchor: A PointParameters constant. This is the anchor of the
            base Drawing.
        add_anchor: A PointParameters constant. This is the anchor of the added
            Drawing.

    Returns:
        A ReportLab Drawing.
    """
    point = get_point_at_parameters(base_drawing, parameters=base_anchor.value)
    from_point = get_point_at_parameters(add_drawing, parameters=add_anchor.value)
    dx, dy = translation_vector_from_drawing(add_drawing, point=point, from_point=from_point)
    s_parameters = (
        add_anchor.value[0] - base_anchor.value[0],
        add_anchor.value[1] - base_anchor.value[1]
    )
    pad_parameters = tuple(0 if abs(value) != 1 else value for value in s_parameters)

    dx = dx - pad_parameters[0] * pad
    dy = dy - pad_parameters[1] * pad
    translate_drawing = translate_drawing_contents(add_drawing, dx, dy)
    merged_drawings = merge_drawings([base_drawing, translate_drawing])

    return merged_drawings


def group_north_arrow(north: float = 0, radius: float = 10) -> Group:
    """Create a Group of a north arrow.
    
    This function will create a Group of a north arrow with the north arrow
    and a circle around it.
    
    Args:
        north: Angle of the north arrow in degrees. A positive value will rotate
            the north arrow clockwise.
        radius: Radius of the north arrow.
    
    Returns:
        A ReportLab Group of a north arrow.
    """
    north_arrow = Group(
        Polygon(
            points=rotate_points([-radius * 0.2, 0, radius * 0.2, 0, 0, radius], north),
            fillColor=colors.black,
            strokeColor=colors.black, strokeWidth=0),
        Circle(0, 0, radius, strokeWidth=radius * 0.025, fillOpacity=0),
        PolyLine(rotate_points([-radius, 0, radius, 0], north),
                 strokeWidth=radius * 0.025 / 2))

    return north_arrow


def draw_north_arrow(north: float = 0, radius: float = 10) -> Drawing:
    """Create a Drawing of a north arrow.

    This function will create a Drawing of a north arrow with the north arrow
    and a circle around it
    
    Args:
        north: Angle of the north arrow in degrees. A positive value will rotate
            the north arrow clockwise.
        radius: Radius of the north arrow.
    
    Returns:
        A ReportLab Drawing of a north arrow.
    """
    north_arrow_drawing = Drawing(width=radius*2, height=radius*2)
    group = group_north_arrow(north, radius)
    for elem in group.contents:
        north_arrow_drawing.add(elem)

    return north_arrow_drawing
