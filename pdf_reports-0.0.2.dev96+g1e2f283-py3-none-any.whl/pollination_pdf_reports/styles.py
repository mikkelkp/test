from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, \
    _baseFontName, _baseFontNameB
from reportlab.lib.colors import blue
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_JUSTIFY


STYLES = getSampleStyleSheet()
STYLES['BodyText'].leading = 18
STYLES['BodyText'].alignment = TA_JUSTIFY
STYLES.add(ParagraphStyle(name='Normal_BOLD',
                          parent=STYLES['Normal'],
                          fontName=_baseFontNameB)
)
STYLES.add(ParagraphStyle(name='Normal_CENTER',
                          parent=STYLES['Normal'],
                          alignment=TA_CENTER,
                          fontSize=10,
                          leading=12)
)
STYLES.add(ParagraphStyle(name='Normal_RIGHT',
                          parent=STYLES['Normal'],
                          alignment=TA_RIGHT,
                          fontSize=10,
                          leading=12)
)
STYLES.add(ParagraphStyle(name='Heading1_CENTER',
                          parent=STYLES['Heading1'],
                          alignment=TA_CENTER),
           alias='h1_c'
)
STYLES.add(ParagraphStyle(name='Heading2_CENTER',
                          parent=STYLES['Heading2'],
                          alignment=TA_CENTER),
           alias='h2_c'
)
STYLES.add(ParagraphStyle(name='Heading3_CENTER',
                          parent=STYLES['Heading3'],
                          alignment=TA_CENTER),
           alias='h3_c'
)
STYLES.add(ParagraphStyle(name='Normal_URL',
                          fontName=_baseFontName,
                          fontSize=10,
                          leading=12,
                          textColor=blue,
                          underlineColor=blue,
                          underlineWidth=0.5)
)
for i in range(1, 10):
    STYLES.add(ParagraphStyle(name=f'Normal_{i}',
                              parent=STYLES['Normal'],
                              fontSize=i)
    )
    STYLES.add(ParagraphStyle(name=f'Normal_{i}_BOLD',
                              parent=STYLES['Normal'],
                              fontSize=i,
                              fontName=_baseFontNameB)
    )

STYLES.add(ParagraphStyle(name='Heading2_Appendix',
                          parent=STYLES['Heading2']),
           alias='h2_appendix'
)
STYLES.add(ParagraphStyle(name='Heading3_Appendix',
                          parent=STYLES['Heading3']),
           alias='h3_appendix'
)
